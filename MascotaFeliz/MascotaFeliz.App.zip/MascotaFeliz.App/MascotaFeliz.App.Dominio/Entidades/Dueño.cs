using System;
namespace MascotaFeliz.App.Dominio
{
    public class Dueño: Persona
    {
        public string Direccion {get;set;}
        public string Ciudad {get;set;}
        public string Pais {get;set;}        
    }
}
