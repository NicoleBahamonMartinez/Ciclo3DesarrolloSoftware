using System;
namespace MascotaFeliz.App.Dominio
{
    public class Mascota
    {
        public int id {get;set;}
        public string Nombre {get;set;}
        public int Edad {get;set;}
        public string Tipo {get;set;}
        public string Raza {get;set;}
        public string Color {get;set;}
        public Dueño Dueño {get;set;}
        

    }
}
