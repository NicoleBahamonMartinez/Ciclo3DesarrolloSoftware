using System; 
namespace MascotaFeliz.App.Dominio
{
    public class Persona
    {
        public int Id {get;set;}
        public string TipoId {get; set;}
        public string Nombres {get; set;}
        public string Apellidos {get;set;}
        public string NumeroTelefono {get;set;}
        public string Correo {get;set;}
        public string Genero {get;set;}
        
    }
}